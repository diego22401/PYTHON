import math
from flask import render_template, request


def calcular():
    num1 = float(request.form["num1"])
    operacao = request.form["operacao"]

    if operacao == "sqrt":
        if num1 < 0:
            etapas = f"Nao existe raiz real de {num1}"
            resultado = "Erro: numero negativo"
        else:
            resultado = math.sqrt(num1)
            etapas = f"raiz quadrada de {num1} = {resultado}"
        return render_template("calculadora.html", etapas=etapas, resultados=resultado)

    if operacao == "log":
        if num1 <= 0:
            etapas = f"Logaritmo indefinido para {num1}"
            resultado = "Erro: numero deve ser maior que zero"
        else:
            resultado = math.log(num1)
            etapas = f"ln({num1}) = {resultado}"
        return render_template("calculadora.html", etapas=etapas, resultados=resultado)

    if operacao == "bhaskara":
        a = num1
        b = float(request.form["num2"])
        c = float(request.form["num3"])
        delta = b**2 - 4 * a * c

        if a == 0:
            etapas = "O coeficiente a nao pode ser zero"
            resultado = "Erro"
        elif delta < 0:
            etapas = f"delta = {b}^2 - 4 x {a} x {c} = {delta} → sem raizes reais"
            resultado = "Sem raizes reais"
        elif delta == 0:
            x = -b / (2 * a)
            etapas = f"delta = {delta} → uma raiz"
            resultado = f"x = {x}"
        else:
            x1 = (-b + math.sqrt(delta)) / (2 * a)
            x2 = (-b - math.sqrt(delta)) / (2 * a)
            etapas = f"delta = {b}^2 - 4 x {a} x {c} = {delta}"
            resultado = f"x1 = {x1}  |  x2 = {x2}"
        return render_template("calculadora.html", etapas=etapas, resultados=resultado)

    num2 = float(request.form["num2"])

    if operacao == "+":
        resultado = num1 + num2
        etapas = f"{num1} + {num2} = {resultado}"

    elif operacao == "-":
        resultado = num1 - num2
        etapas = f"{num1} - {num2} = {resultado}"

    elif operacao == "*":
        resultado = num1 * num2
        etapas = f"{num1} x {num2} = {resultado}"

    elif operacao == "/":
        if num2 == 0:
            etapas = f"{num1} / 0"
            resultado = "Erro: divisao por zero"
        else:
            resultado = num1 / num2
            etapas = f"{num1} / {num2} = {resultado}"

    elif operacao == "**":
        resultado = num1 ** num2
        etapas = f"{num1} ^ {num2} = {resultado}"

    return render_template("calculadora.html", etapas=etapas, resultados=resultado)
